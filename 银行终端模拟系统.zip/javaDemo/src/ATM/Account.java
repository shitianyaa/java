package ATM;

	class Account {
	    private String cardId; // 卡号
	    private String name; // 姓名
	    private char sex; // 性别
	    private String password; // 密码
	    private double balance; // 余额
	    private double limit; // 取现额度

	    public Account() {}

	    public Account(String cardId, String name, char sex, String password, double balance, double limit) {
	        this.cardId = cardId;
	        this.name = name;
	        this.sex = sex;
	        this.password = password;
	        this.balance = balance;
	        this.limit = limit;
	    }

	    public String getCardId() {
	        return cardId;
	    }

	    public void setCardId(String cardId) {
	        this.cardId = cardId;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public char getSex() {
	        return sex;
	    }

	    public void setSex(char sex) {
	        this.sex = sex;
	    }

	    public String getPassword() {
	        return password;
	    }

	    public void setPassword(String password) {
	        this.password = password;
	    }

	    public double getBalance() {
	        return balance;
	    }

	    public void setBalance(double balance) {
	        this.balance = balance;
	    }

	    public double getLimit() {
	        return limit;
	    }

	    public void setLimit(double limit) {
	        this.limit = limit;
	    }
	}



