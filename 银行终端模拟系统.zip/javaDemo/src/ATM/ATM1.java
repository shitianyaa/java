package ATM;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;


public class ATM1 {
    private static ArrayList<Account> accounts = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);
    private static Account loginAcc; // 当前登录的账户

    public static void main(String[] args) {
        while (true) {
            System.out.println("==欢迎您进入到ATM系统==");
            System.out.println("1.用户开户");
            System.out.println("2.用户登录");
            System.out.println("请选择：");
            int command = sc.nextInt();
            switch (command) {
                case 1:
                    creatAccount(); // 用户开户
                    break;
                case 2:
                    login(); // 用户登录
                    break;
                default:
                    System.out.println("您的输入有误，请重新选择！");
            }
        }
    }

    // 用户开户
    protected static void creatAccount() {
        Account acc = new Account();
        System.out.println("请输入您的账户名称：");
        acc.setName(sc.next());

        while (true) {
            System.out.println("请输入您的性别（男/女）：");
            char sex = sc.next().charAt(0);
            if (sex == '男' || sex == '女') {
                acc.setSex(sex);
                break;
            } else {
                System.out.println("您的输入有误，只能是男或者女！");
            }
        }

        while (true) {
            System.out.println("请输入您的账户密码：");
            String password = sc.next();
            System.out.println("请再次输入您的账户密码：");
            String confirmPassword = sc.next();
            if (password.equals(confirmPassword)) {
                acc.setPassword(password);
                break;
            } else {
                System.out.println("两次输入的密码不一致，请重新输入！");
            }
        }

        System.out.println("请输入您的取现额度：");
        acc.setLimit(sc.nextDouble());

        String newCardId = creatCardId();
        acc.setCardId(newCardId);

        accounts.add(acc);
        System.out.println("恭喜您开户成功，" + acc.getName() + "，您的卡号是：" + acc.getCardId());
    }

    // 用户登录
    protected static void login() {
        System.out.println("==系统登录==");
        if (accounts.size() == 0) {
            System.out.println("当前系统中没有账户，请先开户！");
            return;
        }
        while (true) {
            System.out.println("请输入您的卡号：");
            String cardId = sc.next();
            Account acc = getAccountByCardId(cardId);
            if (acc == null) {
                System.out.println("您输入的卡号不存在！");
            } else {
                while (true) {
                    System.out.println("请输入您的密码：");
                    String password = sc.next();
                    if (acc.getPassword().equals(password)) {
                        System.out.println("恭喜您，登录成功！");
                        loginAcc = acc;
                        showUserCommand(); // 显示用户操作菜单
                        return;
                    } else {
                        System.out.println("您的密码输入有误！");
                    }
                }
            }
        }
    }

    // 显示用户操作菜单
    protected static void showUserCommand() {
        while (true) {
            System.out.println(loginAcc.getName() + "==您可以选择如下功能==");
            System.out.println("1.查询账户");
            System.out.println("2.存款");
            System.out.println("3.取款");
            System.out.println("4.转账");
            System.out.println("5.修改密码");
            System.out.println("6.销户");
            System.out.println("7.退出");
            System.out.println("请选择：");
            int command = sc.nextInt();
            switch (command) {
                case 1:
                    showLoginAccount(); // 查询账户
                    break;
                case 2:
                    deposit(); // 存款
                    break;
                case 3:
                    withdraw(); // 取款
                    break;
                case 4:
                    transfer(); // 转账
                    break;
                case 5:
                    changePassword(); // 修改密码
                    break;
                case 6:
                    deleteAccount(); // 销户
                    return;
                case 7:
                    System.out.println("退出成功，欢迎下次使用！");
                    return;
                default:
                    System.out.println("您的输入有误，请重新选择！");
            }
        }
    }

    // 查询账户
    protected static void showLoginAccount() {
        System.out.println("==您的账户信息如下：==");
        System.out.println("卡号：" + loginAcc.getCardId());
        System.out.println("姓名：" + loginAcc.getName());
        System.out.println("性别：" + loginAcc.getSex());
        System.out.println("余额：" + loginAcc.getBalance());
        System.out.println("取现额度：" + loginAcc.getLimit());
    }

    // 存款
    protected static void deposit() {
        System.out.println("请输入存款金额：");
        double amount = sc.nextDouble();
        if (amount > 0) {
            loginAcc.setBalance(loginAcc.getBalance() + amount);
            System.out.println("存款成功，当前余额：" + loginAcc.getBalance());
        } else {
            System.out.println("存款金额必须大于0！");
        }
    }

    // 取款
    protected static void withdraw() {
        System.out.println("请输入取款金额：");
        double amount = sc.nextDouble();
        if (amount > 0) {
            if (loginAcc.getBalance() >= amount && amount <= loginAcc.getLimit()) {
                loginAcc.setBalance(loginAcc.getBalance() - amount);
                System.out.println("取款成功，当前余额：" + loginAcc.getBalance());
            } else {
                System.out.println("余额不足或超过取现额度！");
            }
        } else {
            System.out.println("取款金额必须大于0！");
        }
    }

    // 转账
    protected static void transfer() {
        System.out.println("请输入对方卡号：");
        String cardId = sc.next();
        Account targetAcc = getAccountByCardId(cardId);
        if (targetAcc == null) {
            System.out.println("对方卡号不存在！");
        } else {
            System.out.println("请输入转账金额：");
            double amount = sc.nextDouble();
            if (amount > 0) {
                if (loginAcc.getBalance() >= amount) {
                    loginAcc.setBalance(loginAcc.getBalance() - amount);
                    targetAcc.setBalance(targetAcc.getBalance() + amount);
                    System.out.println("转账成功，当前余额：" + loginAcc.getBalance());
                } else {
                    System.out.println("余额不足！");
                }
            } else {
                System.out.println("转账金额必须大于0！");
            }
        }
    }

    // 修改密码
    protected static void changePassword() {
        System.out.println("请输入旧密码：");
        String oldPassword = sc.next();
        if (loginAcc.getPassword().equals(oldPassword)) {
            System.out.println("请输入新密码：");
            String newPassword = sc.next();
            System.out.println("请再次输入新密码：");
            String confirmPassword = sc.next();
            if (newPassword.equals(confirmPassword)) {
                loginAcc.setPassword(newPassword);
                System.out.println("密码修改成功！");
            } else {
                System.out.println("两次输入的密码不一致！");
            }
        } else {
            System.out.println("旧密码输入错误！");
        }
    }

    // 销户
    protected static void deleteAccount() {
        if (loginAcc.getBalance() == 0) {
            accounts.remove(loginAcc);
            System.out.println("销户成功！");
            loginAcc = null;
        } else {
            System.out.println("账户余额不为零，无法销户！");
        }
    }

    // 生成卡号
    protected static String creatCardId() {
        Random r = new Random();
        while (true) {
            String cardId = "";
            for (int i = 0; i < 8; i++) {
                cardId += r.nextInt(10);
            }
            if (getAccountByCardId(cardId) == null) {
                return cardId;
            }
        }
    }

    // 根据卡号查找账户
    protected static Account getAccountByCardId(String cardId) {
        for (Account acc : accounts) {
            if (acc.getCardId().equals(cardId)) {
                return acc;
            }
        }
        return null;
    }
}