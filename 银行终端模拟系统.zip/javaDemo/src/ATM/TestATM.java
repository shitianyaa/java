package ATM;

public class TestATM {
    public static void main(String[] args) {
        ATM1 atm = new ATM1();

        // 测试生成卡号功能
        String cardId = atm.creatCardId();
        System.out.println("生成的卡号：" + cardId);

        // 测试开户功能
        atm.creatAccount();

        // 测试登录功能
        atm.login();

        // 测试存款功能
        atm.deposit();

        // 测试取款功能
        atm.withdraw();

        // 测试转账功能
        atm.transfer();

        // 测试修改密码功能
        atm.changePassword();

        // 测试查询账户功能
        atm.showLoginAccount();

        // 测试销户功能
        atm.deleteAccount();
    }
}